

<?php $__env->startSection('title'); ?>
    Inventories
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="panel">
            <div class="box-header with-border">
                <h3 class="box-title">Inventories Summary</h3>
                <div class="box-tools pull-right">
                    <a href="<?php echo e(route('admin.inventories.index')); ?>" class="btn btn-info pull-right"><i class="fa fa-angle-double-up"></i> List of Inventory</a>
                </div>
            </div> <!-- /.box-header -->
           <div class="panel-body">
               <div class="col-md-4 col-lg-4">
                   <div class="panel">
                       <div class="box-header">
                           <h3 class="box-title">Head Quarter </h3>
                       </div> <!-- /.box-header -->
                       <div class="panel-body">
                           <table class="table table-hover table-2nd-no-sort">
                               <thead>
                               <tr>
                                   <th>Category Name</th>
                                   <th>Number of Category</th>
                               </tr>
                               </thead>
                               <tbody>
                               <?php $__currentLoopData = $categories_head; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                       <td><?php echo e($category->category_name); ?></td>
                                       <td><a href="#"><?php echo e(count($category->inventories)); ?></a></td>
                                   </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </tbody>
                           </table>
                       </div> <!-- /.box-body -->
                   </div> <!-- /.box -->
               </div>
               <div class="col-md-4 col-lg-4">
                   <div class="panel">
                       <div class="box-header">
                           <h3 class="box-title">GS Gazipur </h3>
                       </div> <!-- /.box-header -->
                       <div class="panel-body">
                           <table class="table table-hover table-2nd-no-sort">
                               <thead>
                               <tr>
                                   <th>Category Name</th>
                                   <th>Number of Category</th>
                               </tr>
                               </thead>
                               <tbody>
                               <?php $__currentLoopData = $categories_gs1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                       <td><?php echo e($category->category_name); ?></td>
                                       <td><a href="#"><?php echo e(count($category->inventories)); ?></a></td>
                                   </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </tbody>
                           </table>
                       </div> <!-- /.box-body -->
                   </div> <!-- /.box -->
               </div>
               <div class="col-md-4 col-lg-4">
                   <div class="panel">
                       <div class="box-header">
                           <h3 class="box-title">GS Betbhunia </h3>
                       </div> <!-- /.box-header -->
                       <div class="panel-body">
                           <table class="table table-hover table-2nd-no-sort">
                               <thead>
                               <tr>
                                   <th>Category Name</th>
                                   <th>Number of Category</th>
                               </tr>
                               </thead>
                               <tbody>
                               <?php $__currentLoopData = $categories_gs2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                       <td><?php echo e($category->category_name); ?></td>
                                       <td><a href="#"><?php echo e(count($category->inventories)); ?></a></td>
                                   </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </tbody>
                           </table>
                       </div> <!-- /.box-body -->
                   </div> <!-- /.box -->
               </div>
           </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\BSCL-ERP\resources\views/admin/inventory/summary.blade.php ENDPATH**/ ?>