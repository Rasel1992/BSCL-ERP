<?php $__env->startSection('title'); ?>
    Departments
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="panel">
            <div class="box-header with-border">
                <h3 class="box-title">Departments</h3>
                <div class="box-tools pull-right">

                    <a href="<?php echo e(route('admin.departments.create')); ?>" class="button add"> Add Department</a>
                </div>
            </div> <!-- /.box-header -->
            <div class="panel-body">
                <table class="table table-hover table-2nd-no-sort" id="file_export">
                    <thead>
                    <tr>
                        <th>SL</th>
                        <th>Department</th>
                        <th>Designation</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($key + $departments->firstItem()); ?></td>
                            <td> <?php echo e($department->department); ?></td>
                            <td> <?php echo e($department->designation); ?></td>
                            <td>
                            <span class="dropdown">
                                            <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                                                <i class="fa fa-cogs"></i> <span class="caret"></span>
                                            </a>
                                            <ul class="dropdown-menu" style="left: -115px;">
                                                 <form method="POST" action="<?php echo e(route('admin.departments.destroy', $department->id)); ?>" accept-charset="UTF-8" class="data-form">
                                                     <?php echo csrf_field(); ?>
                                                     <?php echo method_field('delete'); ?>
                                                     <li><a href="<?php echo e(route('admin.departments.edit', $department->id)); ?>"><i class="fa fa-edit"></i></a></li>
                                                    <li><a href="javascript:void(0)" @click="destroy"><i class="fa fa-trash-o"></i> </a></li>
                                                  </form>
                                            </ul>
                                        </span>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php if($departments->total()): ?>
                    <div class="row">
                        <div class="col-sm-5">
                            <div class="dataTables_info" id="sortable_info" role="status" aria-live="polite">
                                showing <?php echo e($departments->firstItem()); ?> to <?php echo e($departments->lastItem()); ?>

                                of <?php echo e($departments->total()); ?> entries
                            </div>
                        </div>
                        <div class="col-sm-7">
                            <div class="dataTables_paginate paging_simple_numbers" id="sortable_paginate">
                                <?php echo e($departments->links()); ?>

                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div> <!-- /.box-body -->
        </div> <!-- /.box -->
        <?php echo $__env->make('admin.department.form_import', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        new Vue({
            el: '#app',
            methods: {
                destroy: function () {
                    const $this = $(event.target);

                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        if (result.value) {
                            $this.closest('form').submit();
                        }
                    });
                }
            }
        })
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\BSCL-ERP\resources\views/admin/department/index.blade.php ENDPATH**/ ?>