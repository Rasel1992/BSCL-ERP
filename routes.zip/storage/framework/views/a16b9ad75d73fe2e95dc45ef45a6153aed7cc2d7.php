

<?php $__env->startSection('title'); ?>
    Inventory | QR Code List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="panel">
            <div class="box-header with-border">
                <h3 class="box-title">Inventory QR Code Lists
                    </h3>
                <a href="<?php echo e(route('admin.inventories.index')); ?>" class="btn btn-info pull-right"><i class="fa fa-angle-double-up"></i> List of Inventory</a>
            </div> <!-- /.box-header -->
            <div class="panel-body">
                <table class="table table-hover table-2nd-no-sort">
                    <thead>
                    <tr>
                        <th align="center">QR Code</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $allQrCode = $inventory->count();
                        ?>
                        <tr>
                            <div class="col-md-<?php echo e(++$key == $allQrCode && $key & 1 ? '12':'6'); ?>">
                                <?php echo QrCode::size(100)->generate(url('inventories',$inventory->id));; ?><br>
                                <?php echo e($inventory->asset_code); ?>

                            </div>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php if($inventories->total()): ?>
                    <div class="row">
                        <div class="col-sm-5">
                            <div class="dataTables_info" id="sortable_info" role="status" aria-live="polite">
                                showing <?php echo e($inventories->firstItem()); ?> to <?php echo e($inventories->lastItem()); ?> of <?php echo e($inventories->total()); ?> entries
                            </div>
                        </div>
                        <div class="col-sm-7">
                            <div class="dataTables_paginate paging_simple_numbers" id="sortable_paginate">
                                <?php echo e($inventories->links()); ?>

                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div> <!-- /.box-body -->
        </div> <!-- /.box -->
    </section>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\BSCL-ERP\resources\views/admin/inventory/qr-code-list.blade.php ENDPATH**/ ?>