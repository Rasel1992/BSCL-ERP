

<?php $__env->startSection('title'); ?>
    <?php if(isset($department)): ?> Edit <?php else: ?> Create <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <form method="POST" action="<?php echo e(isset($department) ? route('admin.departments.update', $department->id) : route('admin.departments.store')); ?>" accept-charset="UTF-8" id="create-edit-form" data-toggle="validator" enctype="multipart/form-data" novalidate="true">
            <?php echo csrf_field(); ?>
            <?php echo (isset($department))?'<input name="_method" type="hidden" value="PUT">':''; ?>

            <div class="row">
                <div class="col-md-12 col-lg-12">
                    <h3 class="box-title"><?php if(isset($department)): ?> Edit <?php else: ?> Add <?php endif; ?> Department <a href="<?php echo e(route('admin.departments.index')); ?>" class="btn btn-info pull-right"><i class="fa fa-angle-double-up"></i> Back to List</a></h3>
                    <div class="panel">
                        <div class="panel-body">
                                <div class="col-md-12">
                                    <div class="form-group <?php $__errorArgs = ['department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <label class="with-help">Department</label>
                                        <input class="form-control" placeholder="Department" name="department" value="<?php echo e(old('department')); ?>" type="text" v-model="department.department" required>
                                        <?php $__errorArgs = ['department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <label class="with-help">Designation</label>
                                        <input class="form-control" placeholder="Designation" name="designation" value="<?php echo e(old('designation')); ?>" type="text" v-model="department.designation" required>
                                        <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
                <p class="help-block">* Required Fields.</p>
                <div class="text-right form-footer">
                    <button class="button delete" type="reset">Clear</button>
                    <button class="button save" type="submit">Save</button>
                </div>
            </div>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        new Vue({
            el: '#app',
            data: {
                department: {
                    department: '<?php echo e(old('department', $department->department ?? '')); ?>',
                    designation: '<?php echo e(old('designation', $department->designation ?? '')); ?>',
                },
            }
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\BSCL-ERP\resources\views/admin/department/create-edit.blade.php ENDPATH**/ ?>