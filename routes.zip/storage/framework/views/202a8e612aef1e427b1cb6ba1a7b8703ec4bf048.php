<div id="change-password-modal" class="modal fade" aria-hidden="false">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <form method="POST" accept-charset="UTF-8" id="change-password-form" data-toggle="validator" novalidate="true">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    Form
                </div>
                <div class="modal-body">
                    <div class="form-group <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="password">New password*</label>
                        <div class="row">
                            <div class="col-md-6 nopadding-right">
                                <input class="form-control" placeholder="Password" data-minlength="8" required="" name="password" type="password" value="">
                            </div>
                            <div class="col-md-6 nopadding-left">
                                <input class="form-control" placeholder="Confirm password" data-match="#password" required="" name="password_confirmation" type="password" value="">
                            </div>
                        </div>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="help-block">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="button save" type="submit">Update</button>
                </div>
            </form>
        </div> <!-- / .modal-content -->
    </div> <!-- / .modal-dialog -->
</div>
<?php /**PATH G:\xampp\htdocs\BSCL-ERP\resources\views/components/user/password-update.blade.php ENDPATH**/ ?>