

<?php $__env->startSection('title'); ?>
    Inventories
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="panel">
            <div class="box-header with-border">
                <h3 class="box-title">Inventories</h3>
                <div class="box-tools pull-right">
                    <a class="button add" href="<?php echo e(route('admin.inventories.summary')); ?>">Summary</a>
                    <a class="button add" href="<?php echo e(route('admin.inventories.qr-code-list')); ?>">QR Code List</a>
                    <a href="<?php echo e(route('admin.inventories.create')); ?>" class="button add"> Add Inventory</a>
                </div>
            </div> <!-- /.box-header -->
            <div class="panel-body">
                <table class="table table-hover table-2nd-no-sort" id="file_export">
                    <thead>
                    <tr>
                        <th>SL</th>
                        <th>Asset Code</th>
                        <th>Description</th>
                        <th>Category</th>
                        <th>Allocate To</th>
                        <th>Voucher No</th>
                        <th>Qty</th>
                        <th>Cost</th>
                        <th>Location</th>
                        <th>QR Code</th>
                        <th>Purchase Date</th>
                        <th> </th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($key + $inventories->firstItem()); ?></td>
                            <td> <?php echo e($inventory->asset_code); ?></td>
                            <td> <?php echo e($inventory->description); ?></td>
                            <td> <?php echo e($inventory->category->category_name); ?></td>
                            <td>
                                <?php if($inventory->assign_to == 'user'): ?> <strong>Person:</strong><br> <?php echo e($inventory->user->name); ?>

                                <?php else: ?>
                                    <strong>Department:</strong><br> <?php echo e($inventory->department->department); ?>

                                <?php endif; ?>
                            </td>

                            <td> <?php echo e($inventory->voucher_no); ?></td>
                            <td> <?php echo e($inventory->qty); ?></td>
                            <td> <?php echo e($inventory->cost); ?></td>
                            <td> <?php if($inventory->location == 'hq'): ?> Head Quarter <?php elseif($inventory->location == 'gs1'): ?> GS Gazipur <?php else: ?> GS Bethbunia <?php endif; ?></td>
                            <td>  <?php echo QrCode::size(50)->generate(url('inventories',$inventory->id));; ?></td>
                            <td><?php echo e($inventory->purchase_date); ?></td>
                            <td class="row-options text-muted small">
                                <a href="<?php echo e(route('admin.inventories.show', $inventory->id)); ?>" class="ajax-modal-btn"><i data-toggle="tooltip" data-placement="top" title="Details" class="fa fa-expand"></i></a>&nbsp;
                                <a href="<?php echo e(route('admin.inventories.edit', $inventory->id)); ?>" class="ajax-modal-btn"><i data-toggle="tooltip" data-placement="top" title="Edit" class="fa fa-edit"></i></a>&nbsp;
                                <form method="POST" action="<?php echo e(route('admin.inventories.destroy', $inventory->id)); ?>" accept-charset="UTF-8" class="data-form">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <a href="javascript:void(0)" @click="destroy" class="confirm ajax-silent" title="Trash" data-toggle="tooltip" data-placement="top"><i class="fa fa-trash-o"></i></a>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php if($inventories->total()): ?>
                    <div class="row">
                        <div class="col-sm-5">
                            <div class="dataTables_info" id="sortable_info" role="status" aria-live="polite">
                                showing <?php echo e($inventories->firstItem()); ?> to <?php echo e($inventories->lastItem()); ?> of <?php echo e($inventories->total()); ?> entries
                            </div>
                        </div>
                        <div class="col-sm-7">
                            <div class="dataTables_paginate paging_simple_numbers" id="sortable_paginate">
                                <?php echo e($inventories->links()); ?>

                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div> <!-- /.box-body -->
        </div> <!-- /.box -->
        <?php echo $__env->make('admin.inventory.form_import', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        new Vue({
            el: '#app',
            methods: {
                destroy: function () {
                    const $this = $(event.target);

                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        if (result.value) {
                            $this.closest('form').submit();
                        }
                    });
                }
            }
        })
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\BSCL-ERP\resources\views/admin/inventory/index.blade.php ENDPATH**/ ?>