

<?php $__env->startSection('title'); ?>
    Stocks
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="panel">
            <div class="box-header with-border">
                <h3 class="box-title">Stocks</h3>
                <div class="box-tools pull-right">
                    <a href="<?php echo e(route('admin.stocks.create')); ?>" class="button add"> Add Stock</a>
                </div>
            </div> <!-- /.box-header -->
            <div class="panel-body">
                <table class="table table-hover table-2nd-no-sort">
                    <thead>
                    <tr>
                        <th>SL</th>
                        <th>Description</th>
                        <th>Category</th>
                        <th>Qty</th>
                        <th>Location</th>

                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($key + $stocks->firstItem()); ?></td>
                            <td> <?php echo e($stock->description); ?></td>
                            <td> <?php echo e($stock->category->category_name); ?></td>
                            <td> <?php echo e($stock->qty); ?></td>
                           <td> <?php if($stock->location == 'hq'): ?> Head Quarter <?php elseif($stock->location == 'gs1'): ?> GS Gazipur <?php else: ?> GS Bethbunia <?php endif; ?></td>

                            <td class="row-options text-muted small">
                                <a href="<?php echo e(route('admin.stocks.edit', $stock->id)); ?>" class="ajax-modal-btn"><i data-toggle="tooltip" data-placement="top" title="Edit" class="fa fa-edit"></i></a>&nbsp;
                                <form method="POST" action="<?php echo e(route('admin.stocks.destroy', $stock->id)); ?>" accept-charset="UTF-8" class="data-form">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <a href="javascript:void(0)" @click="destroy" class="confirm ajax-silent" title="Trash" data-toggle="tooltip" data-placement="top"><i class="fa fa-trash-o"></i></a>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($stocks->appends(Request::except('page'))->links()); ?>

            </div> <!-- /.box-body -->
        </div> <!-- /.box -->
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        new Vue({
            el: '#app',
            methods: {
                destroy: function () {
                    const $this = $(event.target);

                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        if (result.value) {
                            $this.closest('form').submit();
                        }
                    });
                }
            }
        })
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\BSCL-ERP\resources\views/admin/stock/index.blade.php ENDPATH**/ ?>