

<?php $__env->startSection('title'); ?>
    Change Password
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <form method="POST" action="<?php echo e(route('admin.profile.updatePassword')); ?>" accept-charset="UTF-8" id="create-edit-form" data-toggle="validator" enctype="multipart/form-data" novalidate="true">
            <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-2 col-lg-2"></div>
            <div class="col-md-8 col-lg-8">
                <h3 class="box-title">Update Password <a href="<?php echo e(route('admin.profile')); ?>" class="btn btn-info pull-right"><i class="fa fa-angle-double-up"></i> Back to Profile</a></h3>
                <div class="panel">
                    <div class="panel-body">
                        <div class="modal-body">
                            <div class="form-group<?php echo e($errors->has('old_password') ? ' has-error' : ''); ?>">
                                <label for="old_password">Current Password</label>
                                <input class="form-control" id="old_password" placeholder="Current Password"
                                       data-minlength="8" name="old_password" type="password" value="<?php echo e(old('old_password')); ?>" required>
                                <?php if($errors->has('old_password')): ?>
                                    <span
                                        class="help-block"><strong><?php echo e($errors->first('old_password')); ?></strong></span>
                                <?php endif; ?>

                                <?php if(session('error')): ?>
                                    <span class="help-block"> <strong><?php echo e(session('error')); ?></strong></span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group<?php echo e($errors->has('new_password') ? ' has-error' : ''); ?>">
                                <label for="password">New Password</label>
                                <div class="row">
                                    <div class="col-md-6 nopadding-right">
                                        <input class="form-control" id="password" placeholder="Password"
                                               data-minlength="8" name="new_password" type="password" value="<?php echo e(old('new_password')); ?>" required>
                                        <?php if($errors->has('new_password')): ?>
                                            <span
                                                class="help-block"><strong><?php echo e($errors->first('new_password')); ?></strong></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-6 nopadding-left">
                                        <input class="form-control" placeholder="Confirm Password"
                                               data-match="#password" name="confirm_password" type="password" value="<?php echo e(old('confirm_password')); ?>"
                                               required>
                                        <?php if($errors->has('confirm_password')): ?>
                                            <span
                                                class="help-block"><strong><?php echo e($errors->first('confirm_password')); ?></strong></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-right form-footer">
                    <button class="button delete" type="reset">Clear</button>
                    <button class="button save" type="submit">Save</button>
                </div>
            </div>
            <div class="col-md-2 col-lg-2"></div>
        </div>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\BSCL-ERP\resources\views/admin/account/change-password.blade.php ENDPATH**/ ?>