

<?php $__env->startSection('title'); ?>
    <?php if(isset($inventory)): ?> Edit <?php else: ?> Create <?php endif; ?> | Inventory
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <form method="POST" action="<?php echo e(isset($inventory) ? route('admin.inventories.update', $inventory->id) : route('admin.inventories.store')); ?>" accept-charset="UTF-8" id="create-edit-form" data-toggle="validator" enctype="multipart/form-data" novalidate="true">
            <?php echo csrf_field(); ?>
            <?php if(isset($inventory)): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>
            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-8">
                    <h3 class="box-title"><?php if(isset($inventory)): ?> Edit <?php else: ?> Add <?php endif; ?> Inventory
                        <a href="<?php echo e(route('admin.inventories.index')); ?>" class="btn btn-info pull-right"><i class="fa fa-angle-double-up"></i> List of Inventory</a>
                    </h3>
                    <div class="panel">
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group <?php $__errorArgs = ['asset_code '];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <label class="with-help">Asset Code <span class="text-danger">*</span></label>
                                        <input class="form-control" placeholder="Asset Code" name="asset_code" value="<?php echo e(old('asset_code ')); ?>" type="text" v-model="inventory.asset_code" required>
                                        <?php $__errorArgs = ['asset_code '];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <label class="with-help">Description</label>
                                        <input class="form-control" placeholder="Description" name="description" value="<?php echo e(old('description')); ?>" v-model="inventory.description" type="text">
                                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group <?php $__errorArgs = ['voucher_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <label class="with-help">Voucher No</label>
                                        <input class="form-control" placeholder="Voucher No" name="voucher_no" value="<?php echo e(old('voucher_no')); ?>" v-model="inventory.voucher_no" type="text">
                                        <?php $__errorArgs = ['voucher_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group <?php $__errorArgs = ['purchase_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <label class="with-help">Purchase Date <span class="text-danger">*</span></label>
                                        <input class="form-control" placeholder="Purchase Date" name="purchase_date" value="<?php echo e(old('purchase_date')); ?>" v-model="inventory.purchase_date" type="date" required>
                                        <?php $__errorArgs = ['purchase_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <label class="with-help">Qty</label>
                                        <input class="form-control" placeholder="Qty" name="qty" value="<?php echo e(old('qty')); ?>" v-model="inventory.qty" type="number">
                                        <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group <?php $__errorArgs = ['cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <label for="cost" class="with-help">Cost</label>
                                        <input class="form-control" placeholder="Cost" name="cost" value="<?php echo e(old('cost')); ?>" v-model="inventory.cost" type="number" id="cost">
                                        <?php $__errorArgs = ['cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <label for="category_id" class="with-help">Asset Category <span class="text-danger">*</span></label>
                                        <select class="form-control select2" id="category_id" name="category_id" v-model="inventory.category_id" v-select2 required>
                                            <?php $__currentLoopData = $categoryData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category_name); ?></option>
                                                <?php if(!empty($cat->nested)): ?>
                                                    <?php $__currentLoopData = $cat->nested; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($nc->id); ?>"> -- <?php echo e($nc->category_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <label for="location" class="with-help">location <span class="text-danger">*</span></label>
                                        <select class="form-control select2" id="location" name="location" v-model="inventory.location" v-select2>
                                            <option value="hq" <?php echo e((isset($inventory->location)?$inventory->location:old('location') == 'hq') ? 'Selected' : ''); ?>>Head Quarter
                                            </option>
                                            <option value="gs1" <?php echo e((isset($inventory->location)?$inventory->location:old('location') == 'gs1') ? 'Selected' : ''); ?>>GS Gazipur
                                            </option>
                                            <option value="gs2" <?php echo e((isset($inventory->location)?$inventory->location:old('location') == 'gs2') ? 'Selected' : ''); ?>>GS Bethbunia
                                            </option>
                                        </select>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="with-help">Assign To</label>
                                </div>
                                <label class="radio-inline">
                                    <input type="radio" value="user" v-model="inventory.assign_to" name="assign_to" <?php echo e(old('assign_to') == 'user' ? 'checked' : ''); ?>>User
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" value="department" v-model="inventory.assign_to" name="assign_to" <?php echo e(old('assign_to') == 'department' ? 'checked' : ''); ?>>Department
                                </label>
                            </div>
                            <br>
                            <div class="row">
                                <div class="col-md-6" v-show="inventory.assign_to == 'user'">
                                    <div class="form-group <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <label for="user_id" class="with-help">User</label>
                                        <select class="form-control select2" id="user_id" name="user_id"
                                                v-model="inventory.user_id" v-select2>
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6" v-show="inventory.assign_to == 'department'">
                                    <div class="form-group <?php $__errorArgs = ['dept_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <label for="dept_id" class="with-help">Department</label>
                                        <select class="form-control select2" id="dept_id" name="dept_id"
                                                v-model="inventory.dept_id" v-select2>
                                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($department->id); ?>"><?php echo e($department->department); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['dept_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="text-right form-footer">
                        <button class="button delete" type="reset">Clear</button>
                        <button class="button save" type="submit">Save</button>
                    </div>
                </div>
                <div class="col-md-2"></div>
            </div>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        new Vue({
            el: '#app',
            data: {
                inventory: {
                    assign_to: '<?php echo e(old('assign_to  ', $inventory->assign_to ?? '')); ?>',
                    asset_code: '<?php echo e(old('asset_code  ', $inventory->asset_code ?? '')); ?>',
                    description: '<?php echo e(old('description', $inventory->description ?? '')); ?>',
                    category_id: '<?php echo e(old('category_id ', $inventory->category_id  ?? '')); ?>',
                    user_id: '<?php echo e(old('user_id ', $inventory->user_id  ?? '')); ?>',
                    dept_id: '<?php echo e(old('dept_id ', $inventory->dept_id  ?? '')); ?>',
                    voucher_no: '<?php echo e(old('voucher_no', $inventory->voucher_no ?? '')); ?>',
                    qty: '<?php echo e(old('qty', $inventory->qty ?? '')); ?>',
                    cost: '<?php echo e(old('cost', $inventory->cost ?? '')); ?>',
                    location: '<?php echo e(old('location', $inventory->location ?? '')); ?>',
                    purchase_date: '<?php echo e(old('purchase_date', $inventory->purchase_date ?? '')); ?>',
                },
                mounted() {
                    this.initLibs();
                },
                methods: {
                    initLibs: function () {
                        setTimeout(function () {
                            $('.select2').select2({
                                width: '100%',
                                placeholder: 'Select',
                            });
                        }, 10);
                    }
                }
            }
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\BSCL-ERP\resources\views/admin/inventory/create-edit.blade.php ENDPATH**/ ?>