<?php $__env->startSection('title'); ?>
    Stocks
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="panel">
            <div class="box-header with-border">
                <h3 class="box-title">Bill Register</h3>
                <div class="box-tools pull-right">
                    <a href="<?php echo e(route('admin.bills.create')); ?>" class="button add"> Add Bill</a>
                </div>
            </div> <!-- /.box-header -->
            <div class="panel-body">
                <table class="table table-hover table-2nd-no-sort">
                    <thead>
                    <tr>
                        <th>Bill No</th>
                        <th>Bill Date</th>
                        <th>Shop Info</th>
                        <th>Invoice No</th>
                        <th>Invoice Date</th>
                        <th>Item Name</th>
                        <th>Subject</th>
                        <th>Qty</th>
                        <th>Category</th>
                        <th>Cost</th>
                        <th>Location</th>
                        <th>Assign To</th>
                        <th>QR Code</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($bill->item_name); ?></td>
                            <td> <?php echo e($bill->item_serial); ?></td>
                            <td> <?php echo e($bill->category->category_name); ?></td>
                            <td> <?php echo e($bill->quantity); ?></td>
                            <td> <?php echo e($bill->purchase_date); ?></td>
                            <td> <?php echo e($bill->location); ?></td>
                            <td> <?php echo e($bill->assign_user); ?></td>
                            <td> <?php echo e($bill->qr_code); ?></td>
                            <td>
                                <?php echo e($bill->created_at->format('M d, Y')); ?>

                            </td>
                            <td class="row-options text-muted small">
                                <a href="<?php echo e(route('admin.bills.edit', $bill->id)); ?>" class="ajax-modal-btn"><i data-toggle="tooltip" data-placement="top" title="Edit" class="fa fa-edit"></i></a>&nbsp;
                                <form method="POST" action="<?php echo e(route('admin.bills.destroy', $bill->id)); ?>" accept-charset="UTF-8" class="data-form">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <a href="javascript:void(0)" @click="destroy" class="confirm ajax-silent" title="Trash" data-toggle="tooltip" data-placement="top"><i class="fa fa-trash-o"></i></a>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php if($bills->total()): ?>
                    <div class="row">
                        <div class="col-sm-5">
                            <div class="dataTables_info" id="sortable_info" role="status" aria-live="polite">
                                showing <?php echo e($bills->firstItem()); ?> to <?php echo e($bills->lastItem()); ?> of <?php echo e($bills->total()); ?> entries
                            </div>
                        </div>
                        <div class="col-sm-7">
                            <div class="dataTables_paginate paging_simple_numbers" id="sortable_paginate">
                                <?php echo e($bills->links()); ?>

                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div> <!-- /.box-body -->
        </div> <!-- /.box -->
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        new Vue({
            el: '#app',
            methods: {
                destroy: function () {
                    const $this = $(event.target);

                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        if (result.value) {
                            $this.closest('form').submit();
                        }
                    });
                }
            }
        })
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\BSCL-ERP\resources\views/admin/bill-register/index.blade.php ENDPATH**/ ?>